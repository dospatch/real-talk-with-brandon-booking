# Real Talk with Brandon — Discord Setup Bot

This Discord.js v14 bot helps set up the server and run an **approval-first** guest process.

## Included
- `/setup-server`: creates podcast categories, channels, and roles; makes the staff category private.
- `/approve-guest`: gives the Approved Guest role and privately DMs the booking link.
- `/decline-guest`: logs the decision and attempts a private message.
- `/send-booking`: re-sends the booking link only to a member with the Approved Guest role.
- `/guest-complete`: swaps Approved Guest for Past Guest.
- `/guest-help`: explains the public guest application process.
- Welcome role/message for new members.
- Basic credential-leak filter that removes likely posted tokens/passwords and alerts staff.

**Important:** Google Form responses remain in Google Forms/Sheets, not in Discord. The response spreadsheet should only be shared with you and trusted reviewers. The bot does not read Google Form submissions or automatically match form responses to Discord users; you review applications and use the slash commands manually.

## 1. Create the Discord bot
1. Open https://discord.com/developers/applications and create an application.
2. Open **Bot** and add a bot user.
3. Copy the bot token. Keep it secret; never post it in Discord or share it with anyone.
4. Under **OAuth2 → URL Generator**, select scopes `bot` and `applications.commands`.
5. Select bot permissions: **Manage Roles**, **Manage Channels**, **View Channels**, **Send Messages**, **Embed Links**, **Read Message History**, **Manage Messages**, and **Moderate Members** only if you later add moderation features that need it. Invite the bot to your server.
6. In the Bot settings, enable **Server Members Intent** and **Message Content Intent** if shown as privileged intents. These are used for welcome roles and the credential-safety filter.

## 2. Configure
1. Install Node.js 20 or newer: https://nodejs.org/
2. Extract this folder.
3. Copy `.env.example` to `.env`.
4. Fill in:
   - `DISCORD_TOKEN`: bot token
   - `CLIENT_ID`: Application ID from Developer Portal → General Information
   - `GUILD_ID`: your server ID (enable Developer Mode in Discord, right-click server icon, Copy Server ID)
   - `OWNER_USER_ID`: your Discord user ID, recommended
5. Keep `.env` private and never commit it to GitHub.

## 3. Install and register commands
Open a terminal in the project folder and run:

```bash
npm install
npm run deploy-commands
npm start
```

Commands are registered to the configured server and should appear shortly.

## 4. Run setup
In your server, run `/setup-server`. The command requires Administrator or Manage Server permission. Check the created categories and permissions. Ensure the bot's role is placed **above the roles it must assign** in Server Settings → Roles.

## 5. Approval workflow
1. Applicants use the link in `#guest-application`.
2. You review responses in the private Google response spreadsheet.
3. Invite/identify the applicant in Discord, then run `/approve-guest` and select them. The bot assigns **Approved Guest** and privately DMs the booking link.
4. If you decline, run `/decline-guest`.
5. After the interview, run `/guest-complete`.

The bot cannot DM users who have blocked server DMs. In that case, ask the approved guest to allow DMs and use `/send-booking`.

## 6. Privacy and security
- Do not post the response spreadsheet link in a public channel.
- Only you and authorized reviewers should have spreadsheet access.
- Do not paste bot tokens into chats or screenshots.
- `/approve-guest` private review notes are sent to the private `#staff-logs` channel; keep staff roles restricted.
- The setup command checks for existing matching roles/channels to reduce duplicates. Review the private staff category and test with a non-admin account before launching.
- The basic credential filter is not a full moderation system and can have false positives/negatives. Use Discord AutoMod for spam, slurs, and raid protection as well.

## Known limitations
- Does not connect Google Forms/Sheets API, automatically sync the review tracker, or email applicants.
- It creates a basic server structure; it does not change your server icon, banner, or community settings.
- Discord permissions and role hierarchy can prevent some actions; verify in a test channel.
